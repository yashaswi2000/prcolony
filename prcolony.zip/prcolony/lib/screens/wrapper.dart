import 'package:flutter/material.dart';
import 'package:prcolony/screens/Home/home.dart';

class Wrapper extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Home();
  }
}